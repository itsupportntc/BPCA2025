/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ja=$.ig.locale.ja||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.ja.BulletGraph={rangeNameMissing:"\u017d\u0178\u201a\xcc\u201d\xcd\u02c6\xcd\u201a\xcc\u2013\xbc\u2018O\u201a\xaa\u201a\xa0\u201a\xe8\u201a\xdc\u201a\xb9\u201a\xf1: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.ja.BulletGraph;return $.ig.locale.ja.BulletGraph});