/*!@license
* Infragistics.Web.ClientUI Dialog localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.Dialog=$.ig.Dialog||{};$.ig.locale.bg.Dialog={closeButtonTitle:"\u0417\u0430\u0442\u0432\u043e\u0440\u0438",minimizeButtonTitle:"\u041c\u0438\u043d\u0438\u043c\u0438\u0437\u0438\u0440\u0430\u0439",maximizeButtonTitle:"\u041c\u0430\u043a\u0441\u0438\u043c\u0438\u0437\u0438\u0440\u0430\u0439",pinButtonTitle:"\u0417\u0430\u043a\u0430\u0447\u0438",unpinButtonTitle:"\u041e\u0442\u043a\u0430\u0447\u0438",restoreButtonTitle:"\u0412\u044a\u0437\u0441\u0442\u0430\u043d\u043e\u0432\u0438",setOptionError:"\u0422\u0430\u0437\u0438 \u043e\u043f\u0446\u0438\u044f\u0442\u0430 \u043d\u0435 \u043c\u043e\u0436\u0435 \u0434\u0430 \u0431\u044a\u0434\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043d\u0430 \u043f\u043e \u0432\u0440\u0435\u043c\u0435 \u043d\u0430 \u0438\u0437\u043f\u044a\u043b\u043d\u0435\u043d\u0438\u0435."};$.ig.Dialog.locale=$.ig.Dialog.locale||$.ig.locale.bg.Dialog;return $.ig.locale.bg.Dialog});