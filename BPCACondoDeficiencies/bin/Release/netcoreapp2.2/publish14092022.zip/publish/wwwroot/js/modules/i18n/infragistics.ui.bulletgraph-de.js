/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.de=$.ig.locale.de||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.de.BulletGraph={rangeNameMissing:"Bereichsname fehlt f\xfcr range: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.de.BulletGraph;return $.ig.locale.de.BulletGraph});