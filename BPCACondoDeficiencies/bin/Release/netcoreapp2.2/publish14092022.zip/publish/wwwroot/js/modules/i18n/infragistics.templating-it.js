/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.it=$.ig.locale.it||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale.it.Templating={undefinedArgument:"Si \xe8 verificato un errore durante il tentativo di recuperare la propriet\xe0 dell'origine dati: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale.it.Templating;return $.ig.locale.it.Templating});