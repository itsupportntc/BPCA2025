/*!@license
* Infragistics.Web.ClientUI Combo localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.Combo=$.ig.Combo||{};$.ig.locale.fr.Combo={noMatchFoundText:"Aucun r\xe9sultat",dropDownButtonTitle:"Afficher la liste d\xe9roulante",clearButtonTitle:"Effacer la valeur",placeHolder:"s\xe9lectionner...",notSuported:"L\u2019op\xe9ration n\u2019est pas prise en charge.",errorNoSupportedTextsType:"Un texte de filtrage diff\xe9rent est requis. Fournissez une valeur correspondant soit \xe0 une cha\xeene, soit \xe0 un tableau de cha\xeenes.",errorUnrecognizedHighlightMatchesMode:"Un mode d\u2019association de surbrillance diff\xe9rent est requis. Choisissez une valeur entre \xab\xa0multi\xa0\xbb, \xab\xa0contains\xa0\xbb, \xab\xa0startsWith\xa0\xbb, \xab\xa0full\xa0\xbb et \xab\xa0null\xa0\xbb.",errorIncorrectGroupingKey:"La cl\xe9 de groupement n\u2019est pas correcte."};$.ig.Combo.locale=$.ig.Combo.locale||$.ig.locale.fr.Combo;return $.ig.locale.fr.Combo});