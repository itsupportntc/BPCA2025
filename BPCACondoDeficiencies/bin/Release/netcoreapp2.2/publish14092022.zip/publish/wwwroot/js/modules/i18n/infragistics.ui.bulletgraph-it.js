/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.it=$.ig.locale.it||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.it.BulletGraph={rangeNameMissing:"Nome intervallo mancante per intervallo: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.it.BulletGraph;return $.ig.locale.it.BulletGraph});