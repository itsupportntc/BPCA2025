/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.bg.BulletGraph={rangeNameMissing:"\u041b\u0438\u043f\u0441\u0432\u0430 name \u0437\u0430 range \u0441 \u0438\u043d\u0434\u0435\u043a\u0441: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.bg.BulletGraph;return $.ig.locale.bg.BulletGraph});