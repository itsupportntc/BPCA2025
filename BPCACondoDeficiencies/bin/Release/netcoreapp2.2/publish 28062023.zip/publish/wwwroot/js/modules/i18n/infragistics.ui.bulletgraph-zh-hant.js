/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hant"]=$.ig.locale["zh-Hant"]||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale["zh-Hant"].BulletGraph={rangeNameMissing:"\u7bc4\u570d\u540d\u7a31\u907a\u5931: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale["zh-Hant"].BulletGraph;return $.ig.locale["zh-Hant"].BulletGraph});