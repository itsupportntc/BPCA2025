/*!@license
* Infragistics.Web.ClientUI Combo localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.it=$.ig.locale.it||{};$.ig.Combo=$.ig.Combo||{};$.ig.locale.it.Combo={noMatchFoundText:"Nessuna corrispondenza trovata",dropDownButtonTitle:"Mostra menu a discesa",clearButtonTitle:"Cancella valore",placeHolder:"seleziona...",notSuported:"Operazione non supportata.",errorNoSupportedTextsType:"\xc8 richiesto un testo di filtro diverso. Fornire un valore che \xe8 una stringa o un array di stringhe.",errorUnrecognizedHighlightMatchesMode:"\xc8 necessaria una diversa modalit\xe0 di evidenziazione. Scegliere un valore tra 'multi', 'contains', 'startsWith', 'full' e 'null'.",errorIncorrectGroupingKey:"La chiave di raggruppamento non \xe8 corretta."};$.ig.Combo.locale=$.ig.Combo.locale||$.ig.locale.it.Combo;return $.ig.locale.it.Combo});