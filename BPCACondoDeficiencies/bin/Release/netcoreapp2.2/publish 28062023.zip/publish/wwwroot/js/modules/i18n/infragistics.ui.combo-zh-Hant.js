/*!@license
* Infragistics.Web.ClientUI Combo localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hant"]=$.ig.locale["zh-Hant"]||{};$.ig.Combo=$.ig.Combo||{};$.ig.locale["zh-Hant"].Combo={noMatchFoundText:"\u672a\u627e\u5230\u5339\u914d\u9805",dropDownButtonTitle:"\u986f\u793a\u4e0b\u62c9\u5f0f\u9078\u55ae",clearButtonTitle:"\u6e05\u9664\u503c",placeHolder:"\u9078\u64c7...",notSuported:"\u4e0d\u652f\u63f4\u8a72\u64cd\u4f5c\u3002",errorNoSupportedTextsType:"\u9700\u8981\u4e0d\u540c\u7684\u904e\u6ffe\u6587\u5b57\u3002\u63d0\u4f9b\u7684\u503c\u53ef\u4ee5\u662f\u5b57\u4e32\u6216\u5b57\u4e32\u9663\u5217\u3002",errorUnrecognizedHighlightMatchesMode:"\u9700\u8981\u4f7f\u7528\u4e0d\u540c\u7684\u7a81\u986f\u5339\u914d\u6a21\u5f0f\u3002\u5728 'multi'\uff0c'contains'\uff0c'startsWith'\uff0c'full' \u548c 'null' \u4e4b\u9593\u9078\u64c7\u4e00\u500b\u503c\u3002",errorIncorrectGroupingKey:"\u5206\u7d44\u5bc6\u9470\u4e0d\u6b63\u78ba\u3002"};$.ig.Combo.locale=$.ig.Combo.locale||$.ig.locale["zh-Hant"].Combo;return $.ig.locale["zh-Hant"].Combo});