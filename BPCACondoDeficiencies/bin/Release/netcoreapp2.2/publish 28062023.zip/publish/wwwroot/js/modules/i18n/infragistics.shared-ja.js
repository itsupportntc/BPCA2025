/*!@license
* Infragistics.Web.ClientUI shared localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ja=$.ig.locale.ja||{};$.ig.SharedLocale=$.ig.SharedLocale||{};$.ig.locale.ja.SharedLocale={};$.ig.SharedLocale.locale=$.ig.SharedLocale.locale||$.ig.locale.ja.SharedLocale;return $.ig.locale.ja.SharedLocale});