/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.bg=$.ig.locale.bg||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale.bg.Templating={undefinedArgument:"\u0413\u0440\u0435\u0448\u043a\u0430 \u043f\u0440\u0438 \u043e\u043f\u0438\u0442 \u0434\u0430 \u0441\u0435 \u0432\u0437\u0435\u043c\u0435 \u0441\u0442\u043e\u0439\u043d\u043e\u0441\u0442\u0442\u0430 \u043d\u0430 \u0441\u043b\u0435\u0434\u043d\u043e\u0442\u043e \u0441\u0432\u043e\u0439\u0441\u0442\u0432\u043e \u043e\u0442 \u0438\u0437\u0442\u043e\u0447\u043d\u0438\u043a\u0430 \u043d\u0430 \u0434\u0430\u043d\u043d\u0438: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale.bg.Templating;return $.ig.locale.bg.Templating});