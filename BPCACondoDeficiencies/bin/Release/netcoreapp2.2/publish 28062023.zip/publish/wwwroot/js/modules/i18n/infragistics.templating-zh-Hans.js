/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hans"]=$.ig.locale["zh-Hans"]||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale["zh-Hans"].Templating={undefinedArgument:"\u5c1d\u8bd5\u68c0\u7d22\u6570\u636e\u6e90\u5c5e\u6027\u65f6\u51fa\u73b0\u9519\u8bef: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale["zh-Hans"].Templating;return $.ig.locale["zh-Hans"].Templating});