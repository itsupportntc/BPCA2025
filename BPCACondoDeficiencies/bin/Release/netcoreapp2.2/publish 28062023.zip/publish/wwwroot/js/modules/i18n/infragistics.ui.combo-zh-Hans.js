/*!@license
* Infragistics.Web.ClientUI Combo localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hans"]=$.ig.locale["zh-Hans"]||{};$.ig.Combo=$.ig.Combo||{};$.ig.locale["zh-Hans"].Combo={noMatchFoundText:"\u672a\u627e\u5230\u5339\u914d\u9879",dropDownButtonTitle:"\u663e\u793a\u4e0b\u62c9\u83dc\u5355",clearButtonTitle:"\u6e05\u9664\u503c",placeHolder:"\u9009\u62e9...",notSuported:"\u4e0d\u652f\u6301\u8be5\u64cd\u4f5c\u3002",errorNoSupportedTextsType:"\u9700\u8981\u4e0d\u540c\u7684\u7b5b\u9009\u6587\u672c\u3002\u63d0\u4f9b\u7684\u503c\u53ef\u4ee5\u662f\u5b57\u7b26\u4e32\uff0c\u4e5f\u53ef\u4ee5\u662f\u5b57\u7b26\u4e32\u6570\u7ec4\u3002",errorUnrecognizedHighlightMatchesMode:"\u9700\u8981\u4f7f\u7528\u4e0d\u540c\u7684\u7a81\u51fa\u663e\u793a\u5339\u914d\u6a21\u5f0f\u3002\u5728 'multi'\uff0c'contains'\uff0c'startsWith'\uff0c'full' \u548c 'null' \u4e4b\u95f4\u9009\u62e9\u4e00\u4e2a\u503c\u3002",errorIncorrectGroupingKey:"\u5206\u7ec4\u5bc6\u94a5\u4e0d\u6b63\u786e\u3002"};$.ig.Combo.locale=$.ig.Combo.locale||$.ig.locale["zh-Hans"].Combo;return $.ig.locale["zh-Hans"].Combo});