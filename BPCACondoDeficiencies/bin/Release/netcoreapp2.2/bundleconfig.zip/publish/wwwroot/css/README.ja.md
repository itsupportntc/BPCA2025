==== structure ====

このフォルダーには、Ignite UI for jQuery コンポーネントの構造 （幅、高さ、マージン、パディングなど） に関連するすべてのスタイルが含まれています。このフォルダーのファイルは Ignite UI for jQuery コントロールが正しく動作する上で非常に重要です。

注: structure ファイルはどのテーマにも関連していません。


===== themes =====

Ignite UI for jQuery および jQuery UI コンポーネントのすべてのテーマが含まれるフォルダーです。
Bootstrap 3 - Bootstrap 3 と互換性のあるテーマ
Bootstrap 4 - Bootstrap 4 と互換性のあるテーマ
infragistics
infragistics2012
IOS
Metro
