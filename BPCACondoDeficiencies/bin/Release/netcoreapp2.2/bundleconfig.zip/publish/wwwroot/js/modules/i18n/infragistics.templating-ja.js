/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.ja=$.ig.locale.ja||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale.ja.Templating={undefinedArgument:"\u30c7\u30fc\u30bf \u30bd\u30fc\u30b9 \u30d7\u30ed\u30d1\u30c6\u30a3\u3092\u53d6\u5f97\u3059\u308b\u969b\u306b\u30a8\u30e9\u30fc\u304c\u767a\u751f\u3057\u307e\u3057\u305f: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale.ja.Templating;return $.ig.locale.ja.Templating});