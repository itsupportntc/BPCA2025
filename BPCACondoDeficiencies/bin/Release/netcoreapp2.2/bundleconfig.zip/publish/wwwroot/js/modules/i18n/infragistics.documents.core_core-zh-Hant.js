/*!@license
* Infragistics.Web.ClientUI infragistics.documents.core_core.js resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define([],factory)}else{factory()}})(function(){$=$||{};$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.zh-Hant=$.ig.locale.zh-Hant||{};$.ig.locale.zh-Hant.documentsCore=$.ig.locale.zh-Hant.documentsCore||{};var l=$.ig.locale.zh-Hant.documentsCore;l["LE_ArgumentOutOfRangeException_ValueError"]="\u7121\u6548\u7684 {0} \u503c\u3002\u5b83\u5fc5\u9808\u5728 {1} \u548c {2} \u4e4b\u9593\u3002";l["LE_DocumentEncryptedException_DefaultMessage"]="\u8a72\u6587\u4ef6\u5df2\u52a0\u5bc6\uff0c\u5fc5\u9808\u4f7f\u7528\u5bc6\u78bc\u6253\u958b\u3002";l["LE_EncryptionAlgorithmNotSupportedException_DefaultMessage"]="\u6587\u4ef6\u4f7f\u7528\u4e0d\u53d7\u652f\u63f4\u7684\u52a0\u5bc6\u7b97\u6cd5\u52a0\u5bc6\uff0c\u7121\u6cd5\u89e3\u5bc6\u3002";l["LE_FormatException_TypeError"]="{0} \u683c\u5f0f\u4e0d\u6b63\u78ba: {0}\u3002";l["LE_InvalidPasswordException_DefaultMessage"]="\u6253\u958b\u52a0\u5bc6\u6587\u4ef6\u7684\u5bc6\u78bc\u4e0d\u6b63\u78ba\u3002";$.ig.documentsCore=$.ig.documentsCore||{};$.ig.documentsCore.locale=$.ig.documentsCore.locale||l;return l});