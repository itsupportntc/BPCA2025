/*!@license
* Infragistics.Web.ClientUI templating localization resources 21.1.11
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale["zh-Hant"]=$.ig.locale["zh-Hant"]||{};$.ig.Templating=$.ig.Templating||{};$.ig.locale["zh-Hant"].Templating={undefinedArgument:"\u5617\u8a66\u64f7\u53d6\u8cc7\u6599\u4f86\u6e90\u5c6c\u6027\u6642\u51fa\u932f: "};$.ig.Templating.locale=$.ig.Templating.locale||$.ig.locale["zh-Hant"].Templating;return $.ig.locale["zh-Hant"].Templating});