/*!@license
* Infragistics.Web.ClientUI infragistics.documents.core_core.js resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define([],factory)}else{factory()}})(function(){$=$||{};$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.it=$.ig.locale.it||{};$.ig.locale.it.documentsCore=$.ig.locale.it.documentsCore||{};var l=$.ig.locale.it.documentsCore;l["LE_ArgumentOutOfRangeException_ValueError"]="Valore {0} non valido. Deve essere compreso tra {1} e {2}.";l["LE_DocumentEncryptedException_DefaultMessage"]="Il documento \xe8 crittografato e deve essere aperto con una password.";l["LE_EncryptionAlgorithmNotSupportedException_DefaultMessage"]="Il documento \xe8 crittografato con un algoritmo di crittografia non supportato e non pu\xf2 essere decrittografato.";l["LE_FormatException_TypeError"]="Formato {0} errato: {0}.";l["LE_InvalidPasswordException_DefaultMessage"]="La password utilizzata per aprire il documento crittografato non \xe8 corretta.";$.ig.documentsCore=$.ig.documentsCore||{};$.ig.documentsCore.locale=$.ig.documentsCore.locale||l;return l});