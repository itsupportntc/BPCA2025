/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.fr=$.ig.locale.fr||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.fr.BulletGraph={rangeNameMissing:"Range name is missing for range: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.fr.BulletGraph;return $.ig.locale.fr.BulletGraph});