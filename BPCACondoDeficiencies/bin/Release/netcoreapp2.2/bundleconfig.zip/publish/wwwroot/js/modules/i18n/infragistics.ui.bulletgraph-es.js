/*!@license
* Infragistics.Web.ClientUI Bullet Graph localization resources 21.1.20211.72
*
* Copyright (c) 2011-2021 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/
(function(factory){if(typeof define==="function"&&define.amd){define(["jquery"],factory)}else{return factory(jQuery)}})(function($){$.ig=$.ig||{};$.ig.locale=$.ig.locale||{};$.ig.locale.es=$.ig.locale.es||{};$.ig.BulletGraph=$.ig.BulletGraph||{};$.ig.locale.es.BulletGraph={rangeNameMissing:"El nombre del rango falta para el rango: "};$.ig.BulletGraph.locale=$.ig.BulletGraph.locale||$.ig.locale.es.BulletGraph;return $.ig.locale.es.BulletGraph});